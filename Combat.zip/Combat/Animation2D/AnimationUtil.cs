namespace XiheFramework.Combat.Animation2D {
    public static class AnimationUtil {
        public static string GetAnimation2DEntityAddress(string animationName) {
            return $"Animation2DEntity_{animationName}";
        }
    }
}