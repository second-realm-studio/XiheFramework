namespace XiheFramework.Combat.Animation2D {
    public enum EndBehaviour {
        Stop,
        Loop,
        Pause,
    }
}