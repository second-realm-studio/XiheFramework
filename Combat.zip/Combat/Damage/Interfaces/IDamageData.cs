﻿namespace XiheFramework.Combat.Damage.Interfaces {
    public interface IDamageData {
        uint senderId { get; }
        uint receiverId { get; }
    }
}