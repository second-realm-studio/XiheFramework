using UnityEngine;
using XiheFramework.Core.Base;
using XiheFramework.Core.Entity;
using XiheFramework.Runtime;

namespace XiheFramework.Combat.Particle {
    public class ParticleModule : GameModuleBase {
        public readonly string onParticleCreate = "Particle.OnParticleCreate";
        public readonly string onParticlePlay = "Particle.OnParticlePlay";
        public readonly string onParticleDestroy = "Particle.OnParticleDestroy";

        public ParticleEntityBase CreateParticleEntity(uint ownerId, string particleAddress, Vector3 localPosition, Quaternion localRotation, Vector3 localScale,
            bool followOwner = true) {
            var particleEntity = Game.Entity.InstantiateEntity<ParticleEntityBase>(particleAddress, ownerId, followOwner, 0);
            localScale.Scale(particleEntity.gameObject.transform.localScale);
            particleEntity.Setup(localPosition, localRotation, localScale);
            Game.Event.Invoke(onParticleCreate, ownerId, particleEntity.EntityId);
            return particleEntity;
        }

        public void SetParticlePause(uint particleEntityId, bool pause) {
            var particleEntity = Game.Entity.GetEntity<ParticleEntityBase>(particleEntityId);
            if (particleEntity) {
                particleEntity.particle.Pause(pause);
            }
        }

        public ParticleEntityBase PlayParticle(uint ownerId, string particleAddress, bool loop = false, bool followOwner = false) {
            var ownerEntity = Game.Entity.GetEntity<GameEntityBase>(ownerId);
            if (ownerEntity != null) {
                return PlayParticle(ownerId, particleAddress, ownerEntity.transform.position, ownerEntity.transform.rotation, ownerEntity.transform.localScale, loop, followOwner);
            }

            return null;
        }

        public ParticleEntityBase PlayParticle(uint ownerId, string particleAddress, Vector3 localPosition, Quaternion localRotation, Vector3 localScale, bool loop=false,
            bool followOwner = false) {
            var particle = CreateParticleEntity(ownerId, particleAddress, localPosition, localRotation, localScale, followOwner);
            particle.Play(loop);
            Game.Event.Invoke(onParticlePlay, ownerId, particle.EntityId);

            return particle;
        }

        public void DestroyParticle(uint particleEntityId) {
            Game.Entity.DestroyEntity(particleEntityId);
            Game.Event.Invoke(onParticleDestroy, particleEntityId);
        }

        protected override void Awake() {
            base.Awake();

            Game.Particle = this;
        }
    }
}